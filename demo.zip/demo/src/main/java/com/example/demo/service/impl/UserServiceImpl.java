package com.example.demo.service.impl;

import com.example.demo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Random;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
    private String randNumber;
    @Override
    public String getRand() {
        Random rand = new Random();

        randNumber = new Integer(rand.nextInt(9)).toString() + new Integer(rand.nextInt(9)).toString()
                + new Integer(rand.nextInt(9)).toString() + new Integer(rand.nextInt(9)).toString()
                + new Integer(rand.nextInt(9)).toString() + new Integer(rand.nextInt(9)).toString();
        return randNumber;
    }
}
