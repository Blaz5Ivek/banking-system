package com.example.demo.model.form;

public class formUser {
    public String email;

    public formUser() {
    }

    public formUser(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
