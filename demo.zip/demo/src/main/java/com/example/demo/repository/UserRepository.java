package com.example.demo.repository;

/*@Repository
public class UserRepository extends JpaRepository<user>{
}*/
