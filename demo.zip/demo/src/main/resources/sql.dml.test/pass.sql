insert into passwords(email, pass)
values('testemail@gmail.com', '022456');