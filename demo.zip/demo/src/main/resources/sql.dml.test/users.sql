insert into users (email, cardnumber)
values('testemail@gmail.com', '000000');